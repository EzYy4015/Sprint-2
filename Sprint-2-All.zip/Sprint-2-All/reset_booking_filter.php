<?php
header("Refresh:0; url=manage-bookings.php");
?>