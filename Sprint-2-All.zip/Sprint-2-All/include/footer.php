<?php
    echo 
    '<footer>
    <div class="footer-grass">
    <img src="images/grass-footer1.png">
    </div>
    <div class="footer-container">
        <div class="footer">
            <div class="footer-heading footer1">
                <h2>Navigation</h2>
                <a href="#">Home</a>
                <a href="#">Products</a>
                <a href="#">Bookings</a>
                <a href="#">Guide</a>
                <a href="#">Contact Us</a>
            </div>
            <div class="footer-heading footer2">
            <h2>Developers</h2>
                <a href="#">Ezekiel</a>
                <a href="#">Yuk Fung</a>
                <a href="#">Jing Hong</a>
                <a href="#">Josh</a>
                <a href="#">Cornelius</a>
                <a href="#">Jaden</a>
            </div>
            <div class="footer-heading footer3">
                <h2>Social Media</h2>
                <a href="#">Facebook</a>
                <a href="#">Instagram</a>
                <a href="#">Twitter</a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
    <p>&copy; 2022 - All rights reserved.</p>
    </div>
    </footer>'
?>