<?php
    echo 
    '
    <div class="left-container-icons">
        <a href="profile-management.php">General</a>
        <a href="profile-security.php">Security</a>
        <a href="profile-preferences.php">Preferences</a>
        <a href="profile-purchase-history.php">Purchase History</a>
    </div>
    '
?>