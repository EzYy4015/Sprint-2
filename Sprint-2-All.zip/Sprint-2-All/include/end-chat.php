<?php
    session_start();
    $setsession = $_POST['endchat'];

    $_SESSION['chatid'] = 0;
?>