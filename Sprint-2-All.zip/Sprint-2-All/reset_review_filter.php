<?php
    session_start();
    
    header("Refresh:0; url=admin_review.php");
?>