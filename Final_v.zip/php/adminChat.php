<?php
    session_start();
    include("../include/connection.php");

    $outgoing_id = $_SESSION['userid'];
    $sql = "SELECT * FROM accounts WHERE NOT accID = {$outgoing_id} ORDER BY accID DESC";
    $query = mysqli_query($con, $sql);
    $output = "";
    if(mysqli_num_rows($query) == 0){
        $output .= "No users are available to chat";
    }elseif(mysqli_num_rows($query) > 0){
        include_once "data.php";
    }
    echo $output;
?>
