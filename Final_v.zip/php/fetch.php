
<?php
include("../include/connection.php");
if(isset($_POST['input'])){
  $input = $_POST['input'];
  $query = "SELECT * FROM accounts WHERE accName LIKE '{$input}%'";

  $result = mysqli_query($con,$query);

  if(mysqli_num_rows($result)>0){?>
    <table class="profile-preferences">
        <tr>
            <th>Visitor Name</th>
            <th>Email</th>
            <th>Contact Number</th>
        </tr>
        <?php
    while($row = mysqli_fetch_assoc($result)){
      $name = $row['accName'];
      $email = $row['accEmail'];
      $PNum = $row['accPhoneNo'];

    ?>

      <tr>
        <td><?php echo $name;?></td>
        <td><?php echo $email;?></td>
        <td><?php echo $PNum;?></td>
      </tr>
    <?php
  }?>
  </table>
  <?php
  }
}


?>
