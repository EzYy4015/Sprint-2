<?php
header("Refresh:0; url=../gardening-guide.php");
?>