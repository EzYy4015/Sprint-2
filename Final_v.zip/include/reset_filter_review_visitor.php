<?php
    session_start();
    
    header("Refresh:0; url=../visitor_review.php");
?>