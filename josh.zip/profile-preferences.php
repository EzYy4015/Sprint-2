<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title> Cacti Succulent - Preferences </title>
<link rel="stylesheet" type="text/css" href="style/style-profile2.css"/>
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.1/css/all.css">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
<script src="script/script.js"></script>

</head>
<body>

    <?php

        include("include/navigation.php");
        include("include/connection.php");
        include("include/functions.php");

        check_userlogin();

        $userid = $_SESSION['userid'];

        $searchpreferences = "SELECT p.prodTitle, p.prodDesc FROM acc_preference ap JOIN products p ON p.prodID = ap.prodID WHERE ap.accID = '$userid'";
        $fetchresults = mysqli_query($con, $searchpreferences);
        if(isset($_POST['Save'])){
          echo "<script>alert('good')</script>";
          if (mysqli_num_rows($fetchresults) > 0){
            while($storepreferences = mysqli_fetch_array($fetchresults)){
              $title = $_POST['title'];
              $desc = $_POST['desc'];
              $update = "UPDATE products SET prodTitle = '$title', prodDesc = '$desc' WHERE accID = '$userid'";
              mysqli_query($con, $update);
              echo "<script>alert('updated')</script>";
            }
          }
        }

    ?>


    <div class="mainbody">
        <!-- Your contents go in here, create a new div yah. Better use div for each section -->
        <div class="top-home-button">
            <a href="index.php"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
        </div>
        <div class="profile-main-container">
            <div class="profile-container-left">
                <?php include("include/profile-nav.php"); ?>
            </div>
            <div class="profile-container-right-type2">
                <div class="profile-container-right-iright-type2">
                    <h1>Your Favourited Products</h1>
                    <div class="profile-container-right-iright-contents-type2">
                      <form id="form" method="POST">
                            <?php
                            if (mysqli_num_rows($fetchresults) > 0){
                                echo '
                                <table class="profile-preferences">
                                    <tr>
                                        <th>Product Title</th>
                                        <th>Product Description</th>
                                    </tr>
                                ';
                                while($storepreferences = mysqli_fetch_array($fetchresults)){
                                    echo "<tr><td><input type='text' id='title' name='title' value='" . $storepreferences['prodTitle'] . "'></td>";
                                    echo "<td><textarea id='desc' name='desc' row='10' cols='50'>" . substr($storepreferences['prodDesc'], 0, 150) . "...</textarea></td></tr>";
                                };
                                echo "</table>";
                            } else {
                                echo "You have no favorites.";
                            }
                            ?>
                            <input class="save-button" type="submit" name="Save" value="Save">
                          </form>
                    </div>
                </div>
            </div>
        </div>




        <?php include("include/footer.php"); ?>
    </div>

    <div class="chatbox-wrapper">
    		<div class="chatbox-toggle">
    			<i class='bx bx-message-dots'></i>
    		</div>
    		<div class="chatbox-message-wrapper">
    			<div class="chatbox-message-header">
    				<div class="chatbox-message-profile">
    					<!-- <img src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Nnx8bWFufGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60" alt="" class="chatbox-message-image"> -->
    					<div>
    						<h4 class="chatbox-message-name">
                  <?php
                    echo $_SESSION['userid']
                  ?>
                </h4>
    						<p class="chatbox-message-status">online</p>
    					</div>
    				</div>
    				<div class="chatbox-message-dropdown">
    					<i class='bx bx-dots-vertical-rounded chatbox-message-dropdown-toggle'></i>
    					<ul class="chatbox-message-dropdown-menu">
    						<li>
    							<a href="#">Search</a>
    						</li>
    						<li>
    							<a href="#">Report</a>
    						</li>
    					</ul>
    				</div>
    			</div>
    			<div class="chatbox-message-content">
    				<h4 class="chatbox-message-no-message">You don't have message yet!</h4>
    				<!-- <div class="chatbox-message-item sent">
    					<span class="chatbox-message-item-text">
    						Lorem, ipsum, dolor sit amet consectetur adipisicing elit. Quod, fugiat?
    					</span>
    					<span class="chatbox-message-item-time">08:30</span>
    				</div>
    				<div class="chatbox-message-item received">
    					<span class="chatbox-message-item-text">
    						Lorem, ipsum, dolor sit amet consectetur adipisicing elit. Quod, fugiat?
    					</span>
    					<span class="chatbox-message-item-time">08:30</span>
    				</div> -->
    			</div>
    			<div class="chatbox-message-bottom">
    				<form action="#" class="chatbox-message-form">
    					<textarea rows="1" placeholder="Type message..." class="chatbox-message-input"></textarea>
    					<button type="submit" class="chatbox-message-submit"><i class='bx bx-send' ></i></button>
    				</form>
    			</div>
    		</div>
    	</div>
<script src="script/chatScript.js"></script>


</body>
</html>
